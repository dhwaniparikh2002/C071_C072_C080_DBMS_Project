<?php include 'db_connect.php' ?>
<style>
	#name_card{
		height: 200px;
		width: 90%;
		align-self: center;
		padding-top: 33px;
		box-shadow: 5px 5px 2.5px grey;

	}
	
	#team{
		align-content:  center;
		font-size: 60px;
		font-family: courier;

	}
		
   
</style>
<center><b>
<div id="team">
	TEAM MEMBERS
</div></b>
<br><hr><br><br>
</center>
<div class="row">
  <div class="col-sm-4">
  	<center>
    <div class="card" id="name_card">
      <div class="card-body">
      	<center>
        <h5 class="card-title">Dhwani Parikh</h5>
        <p class="card-text">Roll No.: C071</p>
        </center>        
      </div>
    </div>
</center>
  </div>
  <div class="col-sm-4">
    <div class="card" id="name_card">
      <div class="card-body">
      	<center>
        <h5 class="card-title">Harshul Patawari</h5>
        <p class="card-text">Roll No.: C072</p> 
        </center>       
      </div>
    </div>
  </div>
<div class="col-sm-4">
    <div class="card" id="name_card">
      <div class="card-body">
      	<center>
        <h5 class="card-title">Rajvi Porwal</h5>
        <p class="card-text">Roll No.: C080</p>   
        </center>     
      </div>
    </div>
  </div>
</div>

<!-- <div class="containe-fluid">

	<div class="row">
		<div class="col-lg-12">
			
		</div>
	</div>

	<div class="row mt-3 ml-3 mr-3">
			<div class="col-lg-12">
                <div class="card">
                    <div class="card-body" align="center">

                    <?php echo "Welcome back ". $_SESSION['login_name']."!"  ?>
                                        
                    </div>
                    
                </div>
            </div>
	</div>

</div> -->
<script>
	
</script>